<?php
class SubsController extends Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function store($router)
    {
        $email = $_POST['email'];

        if (empty($email)) {
            header('Location: /?success=false&msg=Please submit a valild email address!');
            exit;
        }

        $subscriber = new SubscriberModel;
        $subscribed = $subscriber->subscribe($email);

        if ($subscribed === true) {
            header('Location: /?success=true&msg=Email subscribed successfully!');
        }
        else {
            header('Location: /?success=false&msg=Something went wrong, please try again!');
        }
        exit;
    }

    public function logout($router)
    {
        session_destroy();
        header('Location: /admin');
        exit;
    }
}