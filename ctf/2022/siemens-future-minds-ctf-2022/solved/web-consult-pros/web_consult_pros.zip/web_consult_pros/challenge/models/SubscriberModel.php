<?php
class SubscriberModel extends Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function subscribe($email)
    {
        return $this->database->query("INSERT INTO subscribers(email) VALUES('$email')");
    }
}
