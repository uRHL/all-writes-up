#!/bin/bash
docker build -t web_consult_pros .
docker run  --name=web_consult_pros --rm -p1337:80 -it web_consult_pros
