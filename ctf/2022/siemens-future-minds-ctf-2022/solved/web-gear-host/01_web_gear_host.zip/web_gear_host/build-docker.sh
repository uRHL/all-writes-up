#!/bin/bash
docker rm -f web_gear_host
docker build -t web_gear_host .
docker run --name=web_gear_host --rm -p1337:1337 -it web_gear_host
