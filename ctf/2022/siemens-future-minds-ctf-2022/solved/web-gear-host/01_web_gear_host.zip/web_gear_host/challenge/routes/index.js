const bot            = require('../bot');
const express        = require('express');
const router         = express.Router();

let db;
let botVisiting = false;

const response = data => ({ message: data });

router.get('/', (req, res) => {
	return res.render('index.html');
});

router.get('/pricing', (req, res) => {
	return res.render('pricing.html');
});

router.get('/support', (req, res) => {
	return res.render('support.html');
});

router.get('/tickets', async (req, res, next) => {
	// allow requests from localhost only
	if(req.ip != '127.0.0.1') return res.redirect('/');

	return db.getTickets()
		.then(allTickets => {
			res.render('ticket.html', { allTickets });
		})
		.catch(() => res.status(500).send(response('Something went wrong!')));
});

router.post('/api/submit_ticket', async (req, res) => {
	const { name, email, website, message } = req.body;
	if (botVisiting) res.status(401).send('Please wait for the previous ticket submission to finish!');
	if(name && email && website && message){
		botVisiting = true;
		return db.addTicket(name, email, website, message)
			.then(async () => {
				await bot.visitTicketsPage(db);
				botVisiting = false;
				res.send(response('Ticket submitted successfully! An admin will review the ticket shortly!'));
			})
			.catch(e => {
				console.log(e);
				botVisiting = false;
				return res.send(response('Something went wrong, please try again!'));
			});
	}
	return res.status(403).send(response('Please fill out all the fields first!'));
});

module.exports = database => {
	db = database;
	return router;
};